---
name: 👷 Task
about: If your issue is neither a bug nor feature request.
---

## Type of report

Task

## Provide description of the task

*What steps should be taken to fulfil the task?*

## Other details

* Browser: …
* OS: …
* CKEditor version: …
* Installed CKEditor plugins: …
