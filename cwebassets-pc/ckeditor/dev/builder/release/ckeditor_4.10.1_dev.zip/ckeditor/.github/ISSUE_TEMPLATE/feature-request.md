---
name: ⭐ Feature request
about: If you want to propose something new.
---

## Type of report

Feature request

## Provide description of the new feature

*What is the expected behavior of the proposed feature?*
