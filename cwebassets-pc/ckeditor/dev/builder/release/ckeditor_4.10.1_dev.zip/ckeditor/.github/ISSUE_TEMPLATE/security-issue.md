---
name: 🚨 Security issue
about: If you want to report a security issue.
---

⚠️ Please **DO NOT report security issues here**, use the contact form at https://ckeditor.com/contact/ instead. ⚠️
